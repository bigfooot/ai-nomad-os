# 🚀 AI Nomad OS – Quick Setup Guide

> Rövid, végrehajtható útmutató az első működő rendszerhez.

## Cél
15–30 perc alatt legyen:
- működő NotebookLM jegyzetfüzeted
- struktúrált Notion workspace-ed
- publikus GitHub repód
- előkészített Substack posztod

Nem tanulás. **Implementáció.**

---

## 1. Fiókok (ha még nincs)
- Google → NotebookLM, Gemini, Cloud Run
- Notion → ingyenes fiók
- GitHub → ingyenes fiók
- Substack → ingyenes fiók

Kész. Tovább.

---

## 2. NotebookLM (LAB létrehozása)

1. Menj ide: https://notebooklm.google.com  
2. New notebook  
3. Név: `[META] AI_Nomad_System`  
4. Adj hozzá forrást:
   - másold be a README tartalmát
   - másold be ezt a guide-ot
   - bármilyen saját jegyzeted

### Prompt (másold be szó szerint):
> Based only on the uploaded sources, create a project blueprint with:
> - FRICTION
> - GAP
> - ENGINE
> - PROFIT
> - REMIX ROUTE  
> Format: Markdown.

Kimenet: **Markdown szöveg** → másolható asset.

---

## 3. Notion (PROD tér)

Hozz létre 4 oldalt:
- `00_INDEX`
- `10_LAB`
- `20_BLUEPRINTS`
- `30_PUBLISH`

Használat:
- 10_LAB → NotebookLM kimenetek
- 20_BLUEPRINTS → projekt sablonok
- 30_PUBLISH → kész anyagok (Substack / GitHub linkek)

Ennyi elég induláshoz.

---

## 4. GitHub (publikus bázis)

A repó már él:
https://github.com/bigfooot/ai-nomad-os

Ide kerülnek:
- docs/ → útmutatók
- templates/ → sablonok
- később kód, példák

Ez a projekt „forrása”.

---

## 5. Substack (kirakat)

1. Menj ide: https://substack.com  
2. Create publication  
3. Készíts draft posztot:
   - cím: AI Nomad OS – First Public Build
   - tartalom: blueprint + linkek

Még nem kell publikálni. Csak legyen kész.

---

## Kész vagy, ha:
- van NotebookLM jegyzetfüzeted
- van Notion struktúrád
- a repó él
- van Substack draft

Ha ez megvan: a rendszer működik.

---

## Elv
> Just enough structure.  
> No overengineering.  
> Everything remixable.
